// Claude Code Console: a small desktop app that shows every instruction given to Claude Code on the
// College Dynasty project, lets you give new ones, and publishes the results to GitHub after they pass a check.
const { app, BrowserWindow, ipcMain, shell } = require('electron');
const { spawn, execFile } = require('child_process');
const path = require('path'), fs = require('fs');
const L = require('./lib.js');

let win = null, running = null;
const env = () => ({ ...process.env, PATH: `${process.env.HOME}/.local/bin:/usr/local/bin:/opt/homebrew/bin:${process.env.PATH || ''}` });
const run = (cmd, args, opts = {}) => new Promise(r => execFile(cmd, args, { cwd: L.PROJECT, env: env(), maxBuffer: 1 << 24, ...opts },
  (e, out, err) => r({ code: e ? (e.code || 1) : 0, out: ((out || '') + (err || '')).trim() })));
const gitHead = async () => (await run('git', ['rev-parse', '--short', 'HEAD'])).out;
const publish = msg => run('/bin/zsh', [path.join(L.PROJECT, 'tools', 'publish.sh'), msg], { timeout: 900000 });
const send = (ch, v) => { if (win && !win.isDestroyed()) win.webContents.send(ch, v); };

async function syncStatus() {
  if ((await run('git', ['remote', 'get-url', 'origin'])).code) return { remote: false };
  const dirty = (await run('git', ['status', '--porcelain'])).out.split('\n').filter(Boolean).length;
  const br = (await run('git', ['rev-parse', '--abbrev-ref', 'HEAD'])).out;
  const ahead = +((await run('git', ['rev-list', '--count', `origin/${br}..HEAD`])).out || 0);
  return { remote: true, dirty, ahead, branch: br };
}

function createWindow() {
  win = new BrowserWindow({
    width: 1280, height: 820, minWidth: 900, minHeight: 600, backgroundColor: '#0b0f16', title: 'Claude Code Console',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, sandbox: true },
  });
  win.loadFile(path.join(__dirname, 'index.html'));
  win.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
}

ipcMain.handle('list', () => L.readEntries().map(({ prompt, output, ...rest }) => rest));
ipcMain.handle('get', async (_e, id) => {
  const e = L.readEntries().find(x => x.id === id); if (!e) return null; let on = null;
  if (e.commitAfter) { const r = await run('git', ['branch', '-r', '--contains', e.commitAfter]); on = r.code === 0 ? r.out.length > 0 : null; }
  return { ...e, onGithub: on };
});
ipcMain.handle('transcript', (_e, sid, from) => L.transcript(String(sid), from | 0, 300));
ipcMain.handle('status', () => running ? { running: true, title: running.title, startedAt: running.startedAt, phase: running.phase || '' } : { running: false });
ipcMain.handle('info', () => ({ project: L.PROJECT, log: L.LOG, dry: !!process.env.CLAUDE_CONSOLE_DRYRUN }));
ipcMain.handle('sync', () => syncStatus());
ipcMain.handle('publish', async () => {
  if (running) return { code: 1, out: 'Claude Code is busy. Try again when it finishes.' };
  running = { id: '-', title: 'Pushing to GitHub', startedAt: new Date().toISOString(), phase: 'Checking the game, then pushing' };
  const r = await publish('Update from Claude Code Console'); running = null; send('changed'); return r;
});
ipcMain.handle('openProject', () => shell.openPath(L.PROJECT));
ipcMain.handle('openLog', () => shell.openPath(path.join(L.LOG, 'HISTORY.md')));
ipcMain.handle('openTerminal', () => new Promise(r => execFile('open', ['-a', 'Terminal', path.join(L.PROJECT, 'tools', 'claude-code.command')], () => r(true))));
ipcMain.handle('gitLog', async () => (await run('git', ['log', '--pretty=format:%h  %ad  %s', '--date=short', '-n', '40'])).out);

ipcMain.handle('run', async (_e, title, prompt) => {
  title = String(title || '').trim() || 'Untitled instruction'; prompt = String(prompt || '').trim();
  if (!prompt) return { error: 'Write an instruction first.' };
  if (running) return { error: 'Claude Code is already working on another instruction.' };
  const id = L.nextId(), startedAt = new Date().toISOString(), before = await gitHead();
  const pdir = path.join(L.PROJECT, 'tools', 'prompts'); L.ensure(pdir);
  const pfile = path.join(pdir, `console-${id}-${L.slug(title)}.txt`); fs.writeFileSync(pfile, prompt + '\n');
  running = { id, title, startedAt, phase: 'Claude Code is working' };
  const dry = !!process.env.CLAUDE_CONSOLE_DRYRUN;
  const child = dry
    ? spawn('/bin/sh', ['-c', 'sleep 1; echo "DRY RUN: Claude Code would receive the instruction saved in tools/prompts."'], { cwd: L.PROJECT })
    : spawn('/bin/zsh', [path.join(L.PROJECT, 'tools', 'run-claude-task.sh'), pfile], { cwd: L.PROJECT, env: env() });
  let out = ''; child.stdout.on('data', d => out += d); child.stderr.on('data', d => out += d);
  child.on('close', async code => {
    const after = await gitHead(), sid = dry ? '' : L.findSession(prompt, Date.parse(startedAt) - 5000);
    L.saveEntry({ id, title, prompt, output: out.trim(), startedAt, finishedAt: new Date().toISOString(), exitCode: code,
      commitBefore: before, commitAfter: after, sessionId: sid, source: 'console', note: '' });
    send('changed'); let pub = null;
    if (!dry && !process.env.CLAUDE_CONSOLE_NOPUSH) { running.phase = 'Checking the game, then pushing to GitHub'; pub = await publish(`Claude Code: ${title}`); }
    running = null; send('changed'); if (pub) send('published', pub);
  });
  return { id };
});

app.setName('Claude Code Console');
app.whenReady().then(() => { createWindow(); app.on('activate', () => { if (!BrowserWindow.getAllWindows().length) createWindow(); }); });
app.on('window-all-closed', () => app.quit());
