const $ = id => document.getElementById(id);
const el = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
const when = iso => iso ? new Date(iso).toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }) : 'unknown';
const dur = (a, b) => { if (!a || !b) return ''; const m = Math.round((Date.parse(b) - Date.parse(a)) / 60000); return m < 1 ? 'under a minute' : m + ' min'; };
let entries = [], selected = null, status = { running: false };
function banner(text, kind) { const b = $('banner'); b.textContent = text; b.className = kind || ''; b.hidden = false; clearTimeout(banner.t); banner.t = setTimeout(() => { b.hidden = true; }, 20000); b.onclick = () => { b.hidden = true; }; }
async function updateSync() {
  const s = await window.api.sync(), b = $('sync'), btn = $('btnPush');
  if (!s.remote) { b.textContent = 'GitHub: not connected'; b.className = 'sync bad'; btn.disabled = true; return; }
  if (!s.ahead && !s.dirty) { b.textContent = 'GitHub: up to date'; b.className = 'sync ok'; btn.disabled = true; return; }
  const parts = []; if (s.dirty) parts.push(s.dirty + ' unsaved file' + (s.dirty === 1 ? '' : 's')); if (s.ahead) parts.push(s.ahead + ' commit' + (s.ahead === 1 ? '' : 's') + ' not pushed');
  b.textContent = 'GitHub: ' + parts.join(', '); b.className = 'sync warn'; btn.disabled = !!status.running;
}

async function refresh() {
  entries = await window.api.list(); status = await window.api.status(); renderList(); updateSync();
  if (selected && !entries.find(e => e.id === selected)) selected = null;
  if (!selected && entries.length) selected = entries[entries.length - 1].id;
  if (selected) show(selected);
}
function renderList() {
  const q = $('q').value.toLowerCase(), box = $('list'); box.textContent = '';
  if (status.running) { const r = el('div', 'item'); r.append(el('b', '', status.title), el('span', '', (status.phase || 'Running') + ' since ' + when(status.startedAt)), el('span', 'badge run', 'working')); box.append(r); }
  [...entries].reverse().filter(e => !q || (e.title + e.id).toLowerCase().includes(q)).forEach(e => {
    const d = el('div', 'item' + (e.id === selected ? ' sel' : '')); d.append(el('b', '', `${e.id}. ${e.title}`));
    const s = el('span', '', `${when(e.startedAt)} · ${e.commitBefore || '?'} → ${e.commitAfter || '?'} `);
    s.append(el('span', 'badge' + (e.exitCode === 0 ? '' : ' bad'), e.exitCode === 0 ? 'done' : 'exit ' + e.exitCode)); d.append(s);
    d.onclick = () => { selected = e.id; renderList(); show(e.id); }; box.append(d);
  });
}
async function show(id) {
  const e = await window.api.get(id), box = $('detail'); box.textContent = ''; if (!e) return;
  box.append(el('h2', '', `${e.id}. ${e.title}`));
  box.append(el('div', 'meta', `Started ${when(e.startedAt)} · took ${dur(e.startedAt, e.finishedAt) || 'unknown'} · commits ${e.commitBefore || '?'} → ${e.commitAfter || '?'} · ${e.source} · on GitHub: ${e.onGithub === true ? 'yes' : e.onGithub === false ? 'not yet' : 'unknown'}`));
  if (e.note) box.append(el('div', 'meta', 'Note: ' + e.note));
  box.append(el('h3', '', 'Instruction given to Claude Code'), el('pre', '', e.prompt));
  const cp = el('button', '', 'Copy instruction'); cp.style.marginTop = '8px'; cp.onclick = () => navigator.clipboard.writeText(e.prompt); box.append(cp);
  box.append(el('h3', '', 'Result reported by Claude Code'), el('pre', '', e.output || '(no output captured)'));
  if (e.sessionId) {
    box.append(el('h3', '', 'Full session transcript (every step Claude Code took)'));
    const holder = el('div'); const b = el('button', '', 'Show transcript'); box.append(b, holder);
    b.onclick = async () => { b.remove(); await loadTranscript(e.sessionId, 0, holder); };
  }
}
async function loadTranscript(sid, from, holder) {
  const t = await window.api.transcript(sid, from);
  if (t.missing) { holder.append(el('div', 'meta', 'The session record is no longer on this Mac.')); return; }
  t.events.forEach(x => {
    const d = el('div', 'ev ' + (x.role === 'user' ? 'user' : x.role === 'assistant' ? 'assistant' : 'tool'));
    d.append(el('small', '', `${x.role}${x.name ? ' · ' + x.name : x.kind === 'result' ? ' · result' : ''} · ${when(x.ts)}`), document.createTextNode(x.text)); holder.append(d);
  });
  const next = from + t.events.length;
  if (next < t.total) { const more = el('button', '', `Show more (${t.total - next} left)`); holder.append(more); more.onclick = async () => { more.remove(); await loadTranscript(sid, next, holder); }; }
}
$('q').oninput = renderList;
$('btnNew').onclick = () => { $('newTitle').value = ''; $('newPrompt').value = ''; $('dlgNew').showModal(); };
$('newCancel').onclick = () => $('dlgNew').close();
$('newRun').onclick = async () => {
  const r = await window.api.run($('newTitle').value, $('newPrompt').value);
  if (r.error) { alert(r.error); return; } $('dlgNew').close(); await refresh();
};
$('btnTerm').onclick = () => window.api.openTerminal();
$('btnLog').onclick = () => window.api.openLog();
$('btnProj').onclick = () => window.api.openProject();
$('btnGit').onclick = async () => { $('gitOut').textContent = (await window.api.gitLog()) || '(no history found)'; $('dlgGit').showModal(); };
$('gitClose').onclick = () => $('dlgGit').close();
$('btnPush').onclick = async () => { $('btnPush').disabled = true; banner('Checking the game, then pushing to GitHub...'); const r = await window.api.publish(); banner(r.out || 'Done.', r.code === 0 ? 'ok' : 'bad'); refresh(); };
window.api.onPublished(r => banner(r.out || 'Done.', r.code === 0 ? 'ok' : 'bad'));
window.api.onChange(refresh);
window.api.info().then(i => { $('proj').textContent = i.project + (i.dry ? ' (dry run)' : ''); });
refresh();
setInterval(async () => { const s = await window.api.status(); if (s.running !== status.running) refresh(); }, 3000);
