// One-time: records the instructions already given to Claude Code on this project into claude-log/.
const fs = require('fs'), path = require('path'), os = require('os');
const L = require('./lib.js');
const P = path.join(L.PROJECT, 'tools', 'prompts');
const rd = f => { try { return fs.readFileSync(f, 'utf8').trim(); } catch { return ''; } };
const mt = f => { try { return fs.statSync(f).mtime.toISOString(); } catch { return ''; } };

const plan = path.join(os.homedir(), '.claude', 'plans');
const planFile = fs.existsSync(plan) ? fs.readdirSync(plan).filter(f => f.endsWith('.md')).sort()[0] : '';
const firstPrompt = 'Read CLAUDE.md first. The game has already been split into src/ with tools/build.js. Run npm run build to confirm it builds. ' +
  'Then list the open issues from CLAUDE.md and propose an order to fix them. Do not change any files.';

const items = [
  { title: 'First look: check the build and plan the fixes (read-only)', prompt: firstPrompt,
    outputFile: planFile ? path.join(plan, planFile) : '', before: '3c19cd7', after: '3c19cd7',
    note: 'Run in read-only plan mode, so no files were changed. The result shown is the plan Claude Code saved.' },
  { title: 'Task 1: add realism and balance measurement tests', promptFile: 'task1-measurement-tests.txt', outputFile: '/tmp/task1.log', before: 'ef6face', after: 'ef29e5b',
    note: 'Claude Code wrote tests/realism.js and tests/balance.js, then its run ended early. The assistant ran the tests and made the commit.' },
  { title: 'Task 2: fix rebounds, blocks and other-team noise', promptFile: 'task2-sim-realism-fixes.txt', outputFile: '/tmp/task2.log', before: 'ef29e5b', after: '0bc4c02' },
  { title: 'Task 3: UI click-through test and multi-season money test', promptFile: 'task3-ui-and-nil-tests.txt', outputFile: '/tmp/task3.log', before: '0bc4c02', after: 'e27236b' },
  { title: 'Task 4: asking prices, long careers, season UI checks', promptFile: 'task4-economy-long-careers-verification.txt', outputFile: '/tmp/task4.log', before: 'e27236b', after: '29f99a0' },
];
if (L.readEntries().length) { console.log('claude-log already has entries; nothing to do.'); process.exit(0); }
items.forEach((it, i) => {
  const promptPath = it.promptFile ? path.join(P, it.promptFile) : '';
  const prompt = it.prompt || rd(promptPath);
  const sid = L.findSession(prompt);
  const info = sid ? L.sessionInfo(sid) : { start: '', end: '' };
  L.saveEntry({
    id: String(i).padStart(4, '0'), title: it.title, prompt, output: rd(it.outputFile),
    startedAt: info.start || mt(promptPath), finishedAt: info.end || mt(it.outputFile),
    exitCode: 0, commitBefore: it.before, commitAfter: it.after, sessionId: sid, source: 'backfilled', note: it.note || '',
  });
});
console.log('Recorded', L.readEntries().length, 'instructions in', L.LOG);
