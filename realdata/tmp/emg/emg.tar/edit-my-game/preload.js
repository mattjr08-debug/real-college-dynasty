const { contextBridge, ipcRenderer } = require('electron');
const call = n => (...a) => ipcRenderer.invoke(n, ...a);
contextBridge.exposeInMainWorld('api', {
  sync: call('sync'), estimate: call('estimate'), setNotify: call('setNotify'), testNotify: call('testNotify'), notified: call('notified'), machine: call('machine'), stop: call('stop'), awake: call('awake'), plan: call('plan'), readList: call('readList'), info: call('info'), saveWork: call('saveWork'), current: call('current'), start: call('start'),
  summary: call('summary'), tryBrowser: call('tryBrowser'), tryApp: call('tryApp'), keep: call('keep'), unpushed: call('unpushed'), undo: call('undo'), openProject: call('openProject'),
  onKeepStep: cb => ipcRenderer.on('keepStep', (_e, v) => cb(v)),
  onProgress: cb => ipcRenderer.on('progress', (_e, v) => cb(v)),
  onFinished: cb => ipcRenderer.on('finished', (_e, v) => cb(v)),
});
