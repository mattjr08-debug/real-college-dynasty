// Builds the plan for one edit: which model does the work, and (for a big update) the stages it is split into.
// Pure functions with no Electron, so they can be tested on their own (tests/plan.js).
const MODELS = { sonnet: 'claude-sonnet-5-5', opus: 'claude-opus-5-5' };
const NAMES = { 'claude-sonnet-5-5': 'Sonnet 5.5', 'claude-opus-5-5': 'Opus 5.5' };
const KIND = { play: 'The game plays differently', bug: 'Fix a problem', look: 'Change how it looks', add: 'Add something new', big: 'A big update (many changes)' };
const HEAD = "Read CLAUDE.md first. This request comes from the game's owner, who is not a programmer. Write your final report in plain, non-technical language.";
// Work that touches the game engine, recruiting, the draft, the tournament, money rules or saves is harder, so Smart uses Opus for it.
const HARD = /\b(engine|simulat\w*|draft|portal|tournament|selection|schema|migrat\w*|save[- ]version|turnover|conference structure|fouls?|free throws?|shot clock|streaks?|momentum|recruiting pool|class shape|prospects?|NIL market|revenue|archetypes?|eligibility)\b/i;
const MAX_GROUP = 5, MAX_SWITCHES = 4;

const itemCount = t => (String(t).match(/^[ \t]{0,3}\d{1,3}\.[ \t]/gm) || []).length;
function parseOnly(txt) { const out = new Set(); String(txt || '').split(/[,\s]+/).filter(Boolean).forEach(p => { const m = /^(\d+)-(\d+)$/.exec(p); if (m) { for (let i = +m[1]; i <= +m[2] && i - +m[1] < 100; i++) out.add(i); } else if (/^\d+$/.test(p)) out.add(+p); }); return [...out].sort((a, b) => a - b); }
// Splits a pasted list into items. An item continues over indented lines and "-" bullets; a heading or a new number ends it.
function splitItems(text) {
  const out = []; let cur = null;
  for (const l of String(text).split('\n')) {
    const m = /^[ \t]{0,3}(\d{1,3})\.[ \t]+(.*)$/.exec(l);
    if (m) { cur = { n: +m[1], text: l.trim() }; out.push(cur); }
    else if (cur && (/^[ \t]+\S/.test(l) || /^\s*-\s/.test(l))) cur.text += '\n' + l;
    else if (l.trim() !== '') cur = null;
  }
  return out;
}
// The notes in the list name the items that cannot change game numbers; a batch made only of those needs no baseline.
function noNumberItems(text) {
  const m = /do NOT change game numbers[^\n]*?:\s*items\s+([0-9,\sand]+?)\./i.exec(String(text)); if (!m) return new Set();
  return new Set((m[1].match(/\d+/g) || []).map(Number));
}
function pickModel(text, kind) {
  const t = String(text || '');
  if (t.length > 700) return { key: 'opus', why: 'a long, detailed request' };
  if (kind !== 'look' && HARD.test(t)) return { key: 'opus', why: 'it touches the game engine, recruiting, the draft, the tournament, money rules or saves' };
  return { key: 'sonnet', why: kind === 'look' ? 'a change to how things look' : 'a small, clear change' };
}

const RULES = `Rules for a big update (the checks are tiered so the run stays fast):\n1. BASELINE FIRST. Record two baselines and write both in CLAUDE.md under "Baselines" with the date and the commit (never delete an old baseline). The FULL baseline: npm test, npm run test:realism, TRIALS=6 SEASONS=4 npm run test:balance, npm run test:long, the draft check (freshmen 55 to 80% of the lottery, 40 to 60% of the first round) and the save size after one season. The QUICK baseline: TRIALS=2 SEASONS=3 npm run test:balance.\n` +
  `2. After EACH item run only the cheap checks. npm test (it already builds, so do not run npm run build first). If the item changes a screen, also npm run test:ui:quick (about 45 seconds). If the item can move game numbers, also npm run test:realism and TRIALS=2 SEASONS=3 npm run test:balance, and compare with the QUICK baseline. Do NOT run the full balance check (6 or more trials), npm run test:long or the full npm run test:ui after each item, and do not write extra measuring scripts when an existing test already measures it.\n` +
  `3. After the last item of a stage, if any item in that stage could move game numbers, run the full balance check once (TRIALS=6 SEASONS=4) and compare with the FULL baseline. Run npm run test:long and the full npm run test:ui once, in the final stage only.\n` +
  `4. Commit each item separately with a message that starts with the item number (git add -A, git commit). Do not run git push.\n` +
  `5. Fix or explain any of these: a realism row that was PASS and is now NEAR or FAR; wins minus goal moving by more than 1.5 wins in any level; a tournament rate moving by more than 8 points (unless the item is meant to change it); the draft shares leaving their ranges; save size growing by more than 25%. If you cannot fix it, undo that item with git revert and report it as Not done.\n` +
  `6. Make the smallest change that does each item. Do not change unrelated things. If an item is unclear or unsafe, skip it and say why. If a sample is too small to tell, say so.\n` +
  `7. Never end your turn while a test or other command is still running in the background. Run long checks in the foreground (no trailing &), or wait for them with a sleep loop, read the result, and only then continue. If you ever start something in the background, wait for it and read its result before you finish. Always commit your finished work before you end.`;
const RULES_NB = `Rules for this batch: none of these items should change game numbers, so no baseline is needed. After each item run npm test (it already builds, so do not run npm run build first); if the item changes a screen also run npm run test:ui:quick (about 45 seconds). Commit each item separately with a message that starts with the item number (git add -A, git commit). Do not run git push. Make the smallest change that does each item and do not change unrelated things. If an item is unclear or unsafe, skip it and say why. If a check you run shows that game numbers moved (a realism row, wins or the draft shares), stop that item and report it. Never end your turn while a test or other command is still running in the background. Run long checks in the foreground (no trailing &), or wait for them with a sleep loop, read the result, and only then continue. If you ever start something in the background, wait for it and read its result before you finish. Always commit your finished work before you end.`;
const REPORT_NB = 'a report that covers EVERY item you were asked to do: the number, the title, a status (Done, Partly done, Skipped or Not done), what changed in plain words, what you tested and the results, and anything the owner should check while playing.';
const REPORT = 'a report that covers EVERY item you were asked to do: the number, the title, a status (Done, Partly done, Skipped or Not done), what changed in plain words, what you tested and the results, and anything the owner should check while playing. Then give a short before and after summary of the baseline.';

function composeSingle(type, text) {
  return `${HEAD}\n\nType of change: ${KIND[type] || KIND.play}.\nRequest: ${text}\n\n` +
    `Rules: make the smallest change that does the job and do not change unrelated things. After changing, rebuild (npm run build) and run npm test. ` +
    `Also run the test that matches the change (npm run test:realism for anything that changes game numbers, npm run test:balance for difficulty). For anything that changes a screen, use the quick screen test while you work (npm run test:ui:quick, about 45 seconds) and run the full one (npm run test:ui, about 2 minutes) only once, at the very end. ` +
    `If a check fails, fix it or say so clearly. Commit with a clear message (git add -A, git commit). Do not run git push. Never end your turn while a test or other command is still running in the background. Run long checks in the foreground (no trailing &), or wait for them with a sleep loop, read the result, and only then continue. If you ever start something in the background, wait for it and read its result before you finish. Always commit your finished work before you end.\n\n` +
    `End your report with three short parts: (1) What I changed, in plain words. (2) What I tested and the results. (3) Anything I am unsure about, or that the owner should look at while playing.`;
}
function composeBigOne(text, nums) {
  const which = nums.length ? `Do ONLY these items from the list: ${nums.join(', ')}. Do not touch the other items.` : 'Do every item in the list.';
  return `${HEAD}\n\nType of change: A big update. Below is a numbered list of changes. ${which} Work through the items in order, one at a time.\n\n${RULES}\n\nEnd with ${REPORT}\n\nTHE LIST:\n${text}`;
}

// choice: 'smart' | 'sonnet' | 'opus' | 'default' (default = send no model, so Claude Code uses its own)
function planBase({ type, text, only, model }, opts = {}) {
  text = String(text || '').trim(); const choice = model || 'smart';
  const pick = (t, kind) => choice === 'smart' ? pickModel(t, kind) : choice === 'fast' ? { key: 'sonnet', why: 'you chose Sonnet + Opus check' } : null;
  const mid = (p) => choice === 'smart' || choice === 'fast' ? MODELS[p.key] : choice === 'default' ? null : MODELS[choice];
  const nm = m => m ? NAMES[m] || m : "Claude Code's default";
  if (type !== 'big') {
    const p = pick(text, type), m = mid(p);
    return { single: true, items: 1, switches: 0, why: choice === 'smart' ? `Smart chose ${nm(m)} because this is ${p.why}.` : choice === 'fast' ? 'Sonnet + Opus check uses Sonnet 5.5.' : `You chose ${nm(m)}.`, stages: [{ label: 'The edit', kind: 'edit', model: m, modelName: nm(m), prompt: composeSingle(type, text) }] };
  }
  const all = splitItems(text), onlyN = parseOnly(only), sel = onlyN.length ? all.filter(i => onlyN.includes(i.n)) : all, nums = sel.map(i => i.n);
  if (sel.length < 3) {
    const hard = sel.length ? sel.map(i => pickModel(i.text, 'big')).find(p => p.key === 'opus') || pickModel('', 'big') : pickModel(text, 'big'), m = choice === 'smart' ? MODELS[hard.key] : choice === 'fast' ? MODELS.sonnet : mid(hard);
    return { single: true, items: Math.max(1, onlyN.length || itemCount(text)), switches: 0, why: choice === 'smart' ? `Smart chose ${nm(m)} because ${hard.key === 'opus' ? hard.why : 'these items are small and clear'}.` : `You chose ${nm(m)}.`, stages: [{ label: 'The edit', kind: 'edit', model: m, modelName: nm(m), prompt: composeBigOne(text, onlyN) }] };
  }
  // 3 or more items: baseline stage, then groups of items (grouped by model), then a final check and report
  const itemModel = it => choice === 'smart' ? MODELS[pickModel(it.text, 'big').key] : choice === 'fast' ? MODELS.sonnet : mid(null);
  const groups = []; let sw = 0, last = null;
  for (const it of sel) {
    let m = itemModel(it);
    if (choice === 'smart' && last && m !== last && sw >= MAX_SWITCHES) m = last;
    const g = groups[groups.length - 1];
    if (g && g.model === m && g.items.length < (opts.maxGroup || MAX_GROUP)) g.items.push(it); else { if (last && m !== last) sw++; groups.push({ model: m, items: [it] }); }
    last = m;
  }
  const noNum = noNumberItems(text), skipBase = sel.every(i => noNum.has(i.n)), nb = skipBase ? 1 : 0;
  const first = choice === 'smart' || choice === 'fast' ? MODELS.sonnet : mid(null), reviewM = choice === 'smart' || choice === 'fast' ? MODELS.opus : mid(null), N = groups.length + 2 - nb, off = 2 - nb;
  const stages = [];
  if (!skipBase) stages.push({ label: 'Baseline', kind: 'baseline', model: first, modelName: nm(first),
    prompt: `${HEAD}\n\nType of change: A big update. You will be given a numbered list of changes and you will do them in stages across several messages. This is STAGE 1 of ${N}: the baseline.\n\n${RULES}\n\nDo only this now: record the baseline described in rule 1, write it in CLAUDE.md under "Baselines", and commit it with the message "Baseline". Do not change any game code yet. The items for the next stages are: ${nums.join(', ')}. Here is the whole list for reference:\n${text}` });
  groups.forEach((g, i) => stages.push({ label: `Item${g.items.length > 1 ? 's' : ''} ${g.items.map(x => x.n).join(', ')}`, kind: 'items', model: skipBase && i === 0 ? first : g.model, modelName: nm(skipBase && i === 0 ? first : g.model), items: g.items.map(x => x.n),
    prompt: (skipBase && i === 0 ? `${HEAD}\n\nType of change: A big update. You will be given a numbered list of changes and you will do them in stages across several messages. This is STAGE 1 of ${N}.\n\n${RULES_NB}\n\nDo ONLY these items now, one at a time, in this order: ${g.items.map(x => x.n).join(', ')}.\n\nTheir text:\n${g.items.map(x => x.text).join('\n')}\n\nThe whole list, for reference only (do not do the other items):\n${text}` : `STAGE ${i + off} of ${N}: do ONLY these items now, one at a time, in this order, following the same rules as before (${skipBase ? 'cheap checks only, no baseline' : 'compare with the baseline after each item'}; one commit per item with the item number first; never push): ${g.items.map(x => x.n).join(', ')}.\n\nTheir text:\n${g.items.map(x => x.text).join('\n')}`) }));
  stages.push({ label: 'Final check and report', kind: 'review', model: reviewM, modelName: nm(reviewM),
    prompt: `FINAL STAGE (${N} of ${N}): do not start any new items. ${skipBase ? 'Run npm test and npm run test:ui:quick once' : 'Re-run npm test and the tests that matter for the items you did, compare with the baseline'}, make sure every item has its own commit (say so if one does not), fix small leftovers, then end with ${skipBase ? REPORT_NB : REPORT}` });
  const names = new Set(stages.map(s => s.modelName));
  return { single: false, items: sel.length, switches: sw, why: choice === 'smart' ? `Smart split ${sel.length} items into ${groups.length} group${groups.length === 1 ? '' : 's'} and picked a model for each (${[...names].join(' and ')}). Each switch makes the next stage re-read the conversation, so there are at most ${MAX_SWITCHES}.` : choice === 'fast' ? 'Sonnet + Opus check uses Sonnet 5.5 for the baseline and every item, and Opus 5.5 only for the final check.' : `You chose ${nm(first)} for every stage.`, stages };
}
// ---- FAST MODE: lighter checks, Sonnet, low thinking effort, no screenshot sets, a script instead of a model for the final check ----
const WAIT_TXT = 'Never end your turn while a test or other command is still running in the background. Run long checks in the foreground (no trailing &), or wait for them with a sleep loop, read the result, and only then continue. Always commit your finished work before you end.';
const LIMITS = 'If check.js shows that a game number moved by more than the limits (a realism row going from PASS to NEAR or FAR, wins above goal by more than 1.5, a tournament rate by more than 8 points, the draft shares leaving their ranges, or save size growing by more than 25%), fix it or undo that item with git revert and report it as Not done.';
const RULES_FAST = `Rules for a big update (FAST MODE, keep every step light):\n1. After EACH item run ONE command: node tools/check.js. It builds once, picks the tests that matter for what you changed (screens, game logic, saves) and runs them side by side. Read its summary, fix anything that fails, then commit. Do not run other test commands separately unless check.js tells you to.\n2. Do not take before and after screenshot sets, do not run the full npm run test:ui, test:long or test:mobile, and do not write extra measuring scripts, unless the request asks for it. ${LIMITS}\n3. Commit each item separately with a message that starts with the item number (git add -A, git commit). Do not run git push.\n4. Make the smallest change that does each item. Do not change unrelated things. If an item is unclear or unsafe, skip it and say why.\n5. ${WAIT_TXT}`;
const RULES_NB_FAST = `Rules for this batch (FAST MODE): none of these items should change game numbers, so no baseline is needed. After each item run ONE command: node tools/check.js (it builds once, picks the matching tests and runs them side by side), fix anything that fails, then commit separately with a message that starts with the item number (git add -A, git commit). Do not run git push. Do not take screenshot sets or run the full npm run test:ui, test:long or test:mobile unless asked. Make the smallest change that does each item and do not change unrelated things. If an item is unclear or unsafe, skip it and say why. ${WAIT_TXT}`;
function composeSingleFast(type, text) {
  return `${HEAD}\n\nType of change: ${KIND[type] || KIND.play}.\nRequest: ${text}\n\nRules (FAST MODE, keep it light): make the smallest change that does the job and do not change unrelated things. When you are done, run ONE command: node tools/check.js (it builds once, picks the tests that matter for what you changed and runs them side by side), fix anything that fails, then commit with a clear message (git add -A, git commit). Do not run git push. Do not take screenshot sets and do not run the full npm run test:ui, test:long or test:mobile unless the request asks for it. ${WAIT_TXT}\n\nEnd your report with three short parts: (1) What I changed, in plain words. (2) What I tested and the results. (3) Anything I am unsure about, or that the owner should look at while playing.`;
}
function planSpeed(inp) {
  if (!inp || !inp.fast) return planBase(inp || {});
  const choice = inp.model || 'smart', text = String(inp.text || '').trim(), p = planBase({ ...inp, model: choice === 'smart' ? 'fast' : choice }, { maxGroup: 8 });
  // Risky work (game engine, recruiting, draft, portal, tournament, money rules, saves, balance) gets medium effort and keeps the Opus final check; the script is only for screens and wording.
  const picked = inp.type === 'big' ? (() => { const all = splitItems(text), on = parseOnly(inp.only), sel = on.length ? all.filter(i => on.includes(i.n)) : all; return sel.length ? sel : [{ text }]; })() : [{ text }];
  const risky = picked.some(i => pickModel(i.text, inp.type === 'big' ? 'big' : inp.type).key === 'opus');
  const effort = risky ? 'medium' : 'low';
  p.stages = p.stages.map(st => {
    if (st.kind === 'review') return risky ? { ...st, effort } : { label: 'Final check (script)', kind: 'scripted', model: null, modelName: 'a script, no model', effort: null, prompt: '' };
    let prompt = inp.type !== 'big' ? composeSingleFast(inp.type, text) : st.prompt.split(RULES).join(RULES_FAST).split(RULES_NB).join(RULES_NB_FAST)
      .replace('record the baseline described in rule 1,', 'record a baseline (run node tools/check.js --all and TRIALS=6 SEASONS=4 npm run test:balance, and note the save size after one season),');
    return { ...st, prompt, effort };
  });
  const scripted = p.stages.some(st => st.kind === 'scripted');
  const used = [...new Set(p.stages.filter(st => st.kind !== 'scripted').map(st => st.modelName))].join(' and ');
  const hasReview = p.stages.some(st => st.kind === 'review');
  p.fast = true; p.risky = risky;
  p.why = risky ? `Fast mode is on, but this touches the game engine, recruiting, the draft, the portal, the tournament, money rules, saves or balance, so it uses medium thinking effort${hasReview ? ' and keeps the Opus final check' : ''}. One smart check command after each item, no screenshot sets.`
    : scripted ? `Fast mode is on: ${used} for the work, low thinking effort, one smart check command after each item, no screenshot sets, and the final check is a script that runs every quick test, not a model.` : `Fast mode is on: ${used} for the work, low thinking effort, one smart check command after each item, no screenshot sets.`;
  return p;
}
module.exports = { plan: planSpeed, planBase, pickModel, splitItems, parseOnly, itemCount, composeSingle, composeBigOne, MODELS, NAMES, KIND };
