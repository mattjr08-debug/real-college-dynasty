const $ = id => document.getElementById(id);
const el = (t, c, x) => { const e = document.createElement(t); if (c) e.className = c; if (x != null) e.textContent = x; return e; };
const STEPS = ['Describe the change', 'Check and send', 'Claude Code works', 'See what changed', 'Try it yourself', 'Keep it or undo it'];
const TYPES = { play: ['The game plays differently', 'Change how the game plays (numbers, rules, difficulty).'], bug: ['Fix a problem', 'Something is broken or wrong.'], look: ['Change how it looks', 'Colors, layout, wording, screens.'], add: ['Add something new', 'A new feature, screen or option.'], big: ['A big update (many changes)', 'Paste a numbered list of changes. Claude Code works through them one at a time, checking the game after each.'] };
const EXAMPLES = ['Recruits ask for too much money at small schools. Lower it a little.', 'The Season center page scrolls too much on my laptop. Make it fit.', 'Add a button on the roster page to sort players by overall rating.', 'When I get fired, show a message that explains why.'];
const S = { notify: (() => { try { return localStorage.getItem('emg-notify') !== '0'; } catch (e) { return true; } })(), fast: true, model: 'smart', only: '', updateApp: true, updateWeb: true, step: 1, type: 'play', title: '', text: '', id: '', sum: null, check: null, msg: '', busy: false, done: '', startedAt: 0, phase: '', lines: [], sync: null };


const itemCount = t => (String(t).match(/^[ \t]{0,3}\d{1,3}\.[ \t]/gm) || []).length;
function parseOnly(txt) { const out = new Set(); String(txt || '').split(/[,\s]+/).filter(Boolean).forEach(p => { const m = /^(\d+)-(\d+)$/.exec(p); if (m) { for (let i = +m[1]; i <= +m[2] && i - +m[1] < 100; i++) out.add(i); } else if (/^\d+$/.test(p)) out.add(+p); }); return [...out].sort((a, b) => a - b); }
const itemsForRun = () => S.type === 'big' ? Math.max(1, parseOnly(S.only).length || itemCount(S.text)) : 1;
function autoTitle() { if (S.type === 'big') { const o = parseOnly(S.only); return o.length ? 'Big update: items ' + S.only.trim() : 'Big update'; } return S.text.trim().split(/\s+/).slice(0, 7).join(' '); }
const planInputs = () => ({ type: S.type, text: S.text, only: S.only, model: S.model, fast: S.fast });
const MODEL_CHOICES = [['smart', 'Smart (picks for you)', 'Small, clear changes use Sonnet 5.5. Harder ones (the game engine, recruiting, the draft, the tournament, saves) use Opus 5.5. A big update is split into stages and can switch models between them.'],
  ['fast', 'Sonnet + Opus check', 'Sonnet 5.5 for the baseline and every item, and Opus 5.5 only for the final check of a big update. It only chooses the model. The tests and thinking effort come from the Fast mode box below.'], ['sonnet', 'Sonnet 5.5', 'Always Sonnet 5.5. Faster and lighter on your usage limit.'], ['opus', 'Opus 5.5', 'Always Opus 5.5. The strongest, but it uses noticeably more of your usage limit.'], ['default', "Claude Code's default", 'Send no model and let Claude Code decide.']];
async function refreshSync() {
  S.sync = await window.api.sync(); const b = $('sync'); let t = '', k = '';
  if (!S.sync.remote) { t = 'GitHub: not connected'; k = 'bad'; }
  else if (S.sync.dirty) { t = `You have ${S.sync.dirty} unsaved changed file${S.sync.dirty === 1 ? '' : 's'}.`; k = 'warn'; }
  else if (S.sync.ahead) { t = `${S.sync.ahead} saved change${S.sync.ahead === 1 ? '' : 's'} not on GitHub yet.`; k = 'warn'; }
  else { t = 'Everything is saved and on GitHub.'; k = 'ok'; }
  const clickable = S.sync.remote && (S.sync.ahead > 0 || S.sync.dirty > 0);
  b.textContent = t; b.className = k + (clickable ? ' click' : ''); b.onclick = clickable ? openPush : null; b.title = clickable ? 'Click to push to GitHub' : '';
  if (clickable) b.append(el('b', '', 'Click to push to GitHub'));
  const nb = $('nextBtn'); if (nb && S.step === 1) nb.disabled = !(S.text.trim().length >= 10 && !(S.sync && S.sync.dirty > 0));
}
// The push window: click the GitHub status box on the left. Lists what is only on this Mac, then checks the game and pushes (optionally also the phone website and the desktop app).
let pushStatus = null; window.api.onKeepStep(t => { if (pushStatus) pushStatus.textContent = t; });
async function openPush() {
  if ($('pushOverlay')) return;
  const info = await window.api.unpushed(), ov = el('div', 'push-overlay'); ov.id = 'pushOverlay'; const box = el('div', 'box'); ov.append(box); document.body.append(ov);
  const close = () => { pushStatus = null; ov.remove(); refreshSync(); }; ov.onclick = (ev) => { if (ev.target === ov && !box.dataset.busy) close(); };
  box.append(el('h3', '', 'Push to GitHub'));
  if (info.running) { box.append(el('div', 'bad', 'An edit is running right now. Wait until it finishes, then push.')); const row = el('div', 'row'); row.append(btn('Close', '', close)); box.append(row); return; }
  const n = info.commits.length;
  box.append(el('div', 'muted', n ? `${n} saved change${n === 1 ? ' is' : 's are'} only on this Mac:` : 'Nothing saved is waiting, but you have unsaved files.'));
  if (n) { const ul = el('ul'); info.commits.slice(0, 6).forEach(c => ul.append(el('li', '', c.s.length > 110 ? c.s.slice(0, 107) + '...' : c.s))); if (n > 6) ul.append(el('li', 'muted', `and ${n - 6} more`)); box.append(ul); }
  if (info.dirty > 0) { const w = el('div', 'muted', `You also have ${info.dirty} unsaved changed file${info.dirty === 1 ? '' : 's'}. They will be saved first, then pushed.`); w.style.color = '#f6c177'; box.append(w); }
  const opt = (label, key) => { const l = el('label'), c = el('input'); c.type = 'checkbox'; c.checked = !!S['push' + key]; c.onchange = () => { S['push' + key] = c.checked; }; l.append(c, document.createTextNode(label)); return l; };
  box.append(opt('Also update the phone website (about a minute)', 'Web'), opt('Also update my desktop app (closes and reopens the game)', 'App'));
  box.append(el('div', 'muted', 'The game is checked first. If the check fails, nothing is pushed.'));
  const status = el('pre', 'muted'); status.style.cssText = 'white-space:pre-wrap;margin:10px 0 0;font-size:12.5px'; box.append(status); const row = el('div', 'row'); box.append(row);
  const cancel = btn('Cancel', '', close), go = btn('Push to GitHub', 'primary', async () => {
    box.dataset.busy = '1'; go.disabled = true; cancel.disabled = true; pushStatus = status; status.textContent = 'Checking the game, then saving to GitHub...';
    const r = await window.api.keep('Push saved changes', !!S.pushApp, !!S.pushWeb); delete box.dataset.busy; pushStatus = null;
    const ok = r.code === 0; status.className = ok ? 'ok' : 'bad';
    status.textContent = (ok ? '\u2713 ' : 'Not pushed. ') + r.out + (r.web ? `\n\nPhone website: ${r.web.url || r.web.out}` : '') + (r.app ? `\n\nDesktop app: ${r.app.out}` : '');
    row.textContent = ''; row.append(btn('Close', ok ? 'primary' : '', close));
  });
  row.append(cancel, go);
}
function rail() {
  const r = $('steps'); r.textContent = '';
  STEPS.forEach((s, i) => { const fin = !!(S.done && i === 5), d = el('div', 'step' + (S.step === i + 1 && !fin ? ' now' : S.step > i + 1 || fin ? ' done' : '')); d.append(el('div', 'n', S.step > i + 1 || fin ? '\u2713' : String(i + 1)), el('div', '', s)); r.append(d); });
}
const btn = (label, cls, fn, dis) => { const b = el('button', 'big ' + (cls || ''), label); b.onclick = fn; b.disabled = !!dis; return b; };
const go = n => { S.step = n; render(); };

function render() {
  rail(); const c = $('card'); c.textContent = ''; const row = el('div', 'row');
  if (S.step === 1) {
    c.append(el('h2', '', 'What do you want to change?'), el('p', 'lead', 'Describe it the way you would tell a person. Say what you see now and what you would like instead.'));
    c.append(el('label', 'k', 'What kind of change is it?')); const ch = el('div', 'chips');
    for (const k in TYPES) { const x = el('button', 'chip' + (S.type === k ? ' on' : ''), TYPES[k][0]); x.title = TYPES[k][1]; x.onclick = () => { S.type = k; if (S.titleAuto || !S.title) { S.title = autoTitle(); S.titleAuto = true; } render(); }; ch.append(x); } c.append(ch);
    c.append(el('label', 'k', 'Which model should do the work?')); const mc = el('div', 'chips');
    for (const [k, label, help] of MODEL_CHOICES) { const x = el('button', 'chip' + (S.model === k ? ' on' : ''), label); x.title = help; x.onclick = () => { S.model = k; render(); }; mc.append(x); } c.append(mc);
    c.append(el('div', 'muted', MODEL_CHOICES.find(m => m[0] === S.model)[2]));
    const fl = el('label', 'fastbox'); fl.style.cssText = 'display:flex;align-items:center;gap:8px;margin:14px 0 4px;font-weight:700;cursor:pointer'; const cb = el('input'); cb.type = 'checkbox'; cb.checked = S.fast; cb.onchange = () => { S.fast = cb.checked; render(); };
    const nl = el('label', 'notifybox'); nl.style.cssText = 'display:flex;align-items:center;gap:8px;margin:14px 0 4px;font-weight:700;cursor:pointer'; const nb = el('input'); nb.type = 'checkbox'; nb.checked = S.notify;
    nb.onchange = () => { S.notify = nb.checked; try { localStorage.setItem('emg-notify', nb.checked ? '1' : '0'); } catch (e) { /* ignore */ } window.api.setNotify(S.notify); render(); }; nl.append(nb, document.createTextNode('\uD83D\uDD14 Notify me on my Mac (banner, sound and Dock bounce)'));
    const tb = el('button', 'small'); tb.textContent = 'Send a test notification'; tb.style.marginLeft = '10px'; tb.onclick = (ev) => { ev.preventDefault(); window.api.testNotify(); }; nl.append(tb);
    window.api.setNotify(S.notify);
    fl.append(cb, document.createTextNode('\u26A1 Fast mode')); c.append(fl, el('div', 'muted', (S.notify ? 'Notifications on: a Mac notification when an edit finishes, stops or needs you, and if macOS is waiting for a permission. ' : 'Notifications off. ') + (S.fast ? 'On: Sonnet unless you pick Opus, low thinking effort, one smart check command after each item, no screenshot sets, bigger groups of items, and the final check done by a script. Claude Code is also asked to finish and commit if it stops early. Turn it off for risky changes.' : 'Off: the normal checks, with a model doing the final check.'))); c.append(nl);
    c.append(el('label', 'k', S.type === 'big' ? 'Your list (numbered items)' : 'Your request')); const ta = el('textarea'); ta.value = S.text; ta.placeholder = S.type === 'big' ? 'Paste your numbered list here, for example:\n13. Re-measure balance...\n14. Fix the Undo check...' : 'For example: ' + EXAMPLES[0]; if (S.type === 'big') ta.style.minHeight = '260px'; ta.oninput = () => { S.text = ta.value; if (!S.title || S.titleAuto) { S.title = autoTitle(); S.titleAuto = true; } if (S.type === 'big') warnBig(); nx.disabled = !ok(); }; c.append(ta);
    if (S.type === 'big') { const lb = btn('Load my saved list (my-list.md)', '', async () => { const t = await window.api.readList(); if (!t.trim()) { S.msg = 'No saved list found. Put a file called my-list.md in the project folder.'; render(); return; } S.text = t; S.msg = ''; if (S.titleAuto || !S.title) { S.title = autoTitle(); S.titleAuto = true; } render(); }); lb.style.marginTop = '10px'; c.append(lb); if (S.msg) c.append(el('div', 'bad', S.msg)); }
    const warnBox = el('div', 'box'); warnBox.id = 'bigWarn'; warnBox.style.display = 'none';
    const warnBig = () => { if (S.type !== 'big') return; const n = itemCount(S.text), o = parseOnly(S.only), eff = o.length ? o.filter(i => i <= Math.max(n, i)).length : n; warnBox.style.display = n || o.length ? 'block' : 'none'; warnBox.textContent = ''; warnBox.append(el('h3', '', n ? `I can see ${n} numbered item${n === 1 ? '' : 's'} in your list.` : 'I cannot see numbered items yet.'));
      warnBox.append(el('div', eff > 8 ? 'bad' : 'muted', eff > 8 ? `You are asking for ${eff} items in one run. Big lists work better in batches of about 5 to 8, because each item gets checked and a problem is easier to undo. Type the item numbers you want this time in the box below.` : o.length ? `This run will do items ${o.join(', ')}.` : 'This run will do every item. For long lists, type the item numbers you want this time in the box below.')); };
    if (S.type === 'big') { c.append(el('label', 'k', 'Which items this time? (for example 13, 14, 48-50. Leave empty to do every item)')); const oi = el('input'); oi.type = 'text'; oi.value = S.only; oi.placeholder = 'All items'; oi.oninput = () => { S.only = oi.value; if (S.titleAuto) S.title = autoTitle(); warnBig(); }; c.append(oi, warnBox); warnBig(); }
    if (S.type !== 'big') { c.append(el('label', 'k', 'Need an idea? Click one to start from it:')); const ex = el('div', 'chips'); EXAMPLES.forEach(t => { const x = el('button', 'chip ex', t); x.onclick = () => { S.text = t; S.title = t.split(/\s+/).slice(0, 7).join(' '); S.titleAuto = true; render(); }; ex.append(x); }); c.append(ex); }
    c.append(el('label', 'k', 'Short name for this edit (so you can find it later)')); const ti = el('input'); ti.type = 'text'; ti.value = S.title; ti.oninput = () => { S.title = ti.value; S.titleAuto = false; }; c.append(ti);
    const unsaved = S.sync && S.sync.remote && S.sync.dirty > 0;
    if (unsaved) { const w = el('div', 'box'); w.append(el('h3', '', 'Save your earlier work first'), el('div', 'muted', `You have ${S.sync.dirty} unsaved changed file(s) from before. Save them so this edit starts clean and can be undone on its own.`)); w.append(btn('Save my work now', '', async () => { await window.api.saveWork(); await refreshSync(); render(); })); c.append(w); }
    const ok = () => S.text.trim().length >= 10 && !(S.sync && S.sync.dirty > 0);
    const nx = btn('Next: check and send', 'primary', () => go(2), !ok()); nx.id = 'nextBtn'; row.append(el('div', 'sp'), nx); c.append(row);
  } else if (S.step === 2) {
    c.append(el('h2', '', 'Check, then send it to Claude Code'), el('p', 'lead', 'This is exactly what Claude Code will be told. Nothing is sent until you click the button.'));
    const b1 = el('div', 'box'); b1.append(el('h3', '', 'Your edit: ' + (S.title || 'My edit')));
    if (S.type === 'big' && S.text.trim().length > 600) { const n = itemCount(S.text), dd = document.createElement('details'); dd.append(el('summary', '', `Show your full list (${n} numbered items)`), el('pre', '', S.text.trim())); b1.append(dd); } else b1.append(el('pre', '', S.text.trim())); c.append(b1);
    const eb = el('div', 'box'); eb.append(el('h3', '', 'Estimated time'), el('div', 'muted', 'Working it out...')); c.append(eb);
    window.api.estimate(itemsForRun()).then(r => { S.pre = r; eb.textContent = ''; eb.append(el('h3', '', `Estimated time: ${r.text.toLowerCase()} (${r.range})`), el('div', 'muted', `Based on ${r.basis}. This is a guess. It is recalculated every few seconds while Claude Code works and can go up or down.`)); });
    if (S.type === 'big') { const all = [...S.text.matchAll(/^[ \t]{0,3}(\d{1,3})\.[ \t]/gm)].map(m => +m[1]), sel = parseOnly(S.only).length ? all.filter(n => parseOnly(S.only).includes(n)) : all;
      if (sel.length > 8) { const wb = el('div', 'box'); wb.append(el('h3', 'bad', `This run covers ${sel.length} items`), el('div', 'muted', `That is a very long run, easily many hours, and one problem early on slows everything after it. Runs of about 5 to 8 items finish sooner, are easier to check, and are easier to undo.`));
        wb.append(btn(`Do only items ${sel.slice(0, 8).join(', ')} (the first 8)`, 'primary', () => { S.only = sel.slice(0, 8).join(', '); S.titleAuto = true; S.title = autoTitle(); render(); })); c.append(wb); } }
    const b2 = el('div', 'box'); b2.append(el('h3', '', 'What to expect'), el('div', 'muted', (S.type === 'big' ? 'A big update can take from half an hour to several hours, because every item is checked against the baseline. ' : 'It usually takes 10 to 40 minutes. ') + 'Keep this window open and your Mac awake. Claude Code can change game files, run the tests and save the change on your Mac. It cannot put anything on GitHub by itself. You decide that at the end.')); c.append(b2);
    const mb = el('div', 'box'); mb.append(el('h3', '', 'Model'), el('div', 'muted', 'Working out the plan...')); c.append(mb);
    const d = document.createElement('details'); d.append(el('summary', '', 'Show the full message Claude Code receives'), el('pre', '', '')); c.append(d);
    window.api.machine().then(m => { const slow = m.load > m.cores * 1.2 || m.onBattery || m.busy.length; if (!slow) return; const bx = el('div', 'box');
      bx.append(el('h3', 'bad', 'Your Mac may slow this down'), el('div', 'muted', [m.onBattery ? `It is on battery${m.pct ? ' (' + m.pct + '%)' : ''}.` : '', m.load > m.cores * 1.2 ? `The load is ${m.load} on ${m.cores} cores.` : '', m.busy.length ? 'Busy right now: ' + m.busy.map(b => `${b.name} (${Math.round(b.cpu)}%)`).join(', ') + '.' : ''].filter(Boolean).join(' ') + ' Plug in and close heavy apps for the fastest run.')); mb.parentNode.insertBefore(bx, mb); }).catch(() => {});
    window.api.plan(planInputs()).then(pl => {
      mb.textContent = ''; mb.append(el('h3', '', pl.single ? `Model: ${pl.stages[0].modelName}` : `Plan: ${pl.stages.length} stages`), el('div', 'muted', pl.why));
      if (!pl.single) { const ol = el('div', 'feed'); pl.stages.forEach((st, i) => ol.append(el('div', '', `${i + 1}. ${st.label} \u2014 ${st.modelName}`))); mb.append(ol); }
      mb.append(el('div', 'muted', 'Opus uses more of your usage limit than Sonnet.' + (pl.single ? '' : ' Each stage runs in the same conversation, so Claude Code remembers the earlier stages.')));
      d.querySelector('pre').textContent = pl.stages.map((st, i) => (pl.single ? '' : `===== STAGE ${i + 1} OF ${pl.stages.length}: ${st.label} (${st.modelName}) =====\n`) + st.prompt).join('\n\n'); });
    c.append(el('div', 'muted', S.msg)); row.append(btn('Back', '', () => go(1)), el('div', 'sp'),
      btn('Send to Claude Code', 'primary', async () => { const r = await window.api.start(S.title, planInputs()); if (r.error) { S.msg = r.error; render(); return; } S.id = r.id; S.startedAt = Date.now(); S.phase = 'Claude Code is working'; S.lines = []; go(3); })); c.append(row);
  } else if (S.step === 3) {
    c.append(el('h2', '', 'Claude Code is working'), el('p', 'lead', 'You can leave this window open and do something else. It moves on by itself when finished.'));
    const b = el('div', 'box'); const t = el('h3'); t.append(Object.assign(el('span', 'spin'), {}), document.createTextNode(S.phase)); const tm = el('span', 'muted', ''); tm.id = 'elapsed'; t.append(tm); b.append(t);
    const f = el('div', 'feed'); f.id = 'feed'; f.append(el('div', 'muted', 'Waiting for the first steps...')); b.append(f); c.append(b);
    const eta = el('div', 'box'); eta.append(el('h3', '', 'Time left'), el('div', '')); eta.id = 'eta'; c.append(eta); showEta();
    const sb = el('div', 'box'); sb.append(el('div', 'muted', 'Your Mac is kept awake while this runs. Keep it plugged in. Finished items stay saved if you stop.'), btn('Stop this run', 'danger', async () => { if (!confirm('Stop now? Items already finished stay saved. The item in progress is dropped.')) return; await window.api.stop(); })); sb.lastChild.style.marginTop = '10px'; c.append(sb);
    tick();
  } else if (S.step === 4) {
    const s = S.sum; c.append(el('h2', '', 'Here is what changed'), el('p', 'lead', s ? s.title : ''));
    if (!s) { c.append(el('div', 'muted', 'Loading...')); return; }
    const g = el('div', 'box'); g.append(el('h3', '', 'Game check'), el('div', S.check && S.check.ok ? 'ok' : 'bad', S.check && S.check.ok ? 'Passed: the game loads and a career starts.' : 'FAILED. Do not keep this edit yet.')); if (S.check && !S.check.ok) g.append(el('pre', '', S.check.out)); c.append(g);
    const r = el('div', 'box'); r.append(el('h3', '', "Claude Code's summary"), el('pre', '', s.report || '(no summary was produced)')); c.append(r);
    const f = el('div', 'box'); f.append(el('h3', '', `Files changed (${s.files.length})`));
    if (!s.files.length) f.append(el('div', 'muted', 'No game files changed.')); s.files.slice(0, 30).forEach(x => { const l = el('div', 'file'); l.append(el('span', '', x.file), el('span', 'muted', `+${x.add} -${x.del}`)); f.append(l); }); c.append(f);
    row.append(S.check && !S.check.ok ? btn('Ask Claude Code to fix it', '', () => { S.text = 'The last edit failed the game check. Please fix it. Details: ' + (S.check.out || ''); S.title = 'Fix failed check'; S.titleAuto = false; go(1); }) : el('span'), el('div', 'sp'), btn('Next: try it', 'primary', () => go(5))); c.append(row);
  } else if (S.step === 5) {
    c.append(el('h2', '', 'Try it yourself'), el('p', 'lead', 'Play for a few minutes before you decide. Both buttons run the new version, not the old one.'));
    const t = el('div', 'two'); const a = el('div', 'box'), b = el('div', 'box');
    a.append(el('h3', '', 'Quick look in your browser'), el('div', 'muted', 'Builds the game and opens it in your browser. About 10 seconds. Saves here are separate from the desktop app.'), btn('Open the game in my browser', '', async () => { S.busy = true; S.msg = 'Building...'; render(); const r = await window.api.tryBrowser(); S.busy = false; S.msg = r.out; render(); }, S.busy));
    b.append(el('h3', '', 'Update my desktop app'), el('div', 'muted', 'Rebuilds the College Dynasty app and opens it. About 1 to 3 minutes. Your saved careers inside the app are kept.'), btn('Update the app and open it', '', async () => { S.busy = true; S.msg = 'Updating the desktop app. This takes a minute or two...'; render(); const r = await window.api.tryApp(); S.busy = false; S.msg = r.code === 0 ? 'The desktop app was updated and opened.' : 'The update failed:\n' + r.out; render(); }, S.busy));
    t.append(a, b); c.append(t, el('pre', S.msg.startsWith('The update failed') ? 'bad' : 'muted', S.msg));
    row.append(btn('Back', '', () => go(4)), el('div', 'sp'), btn('I have tried it', 'primary', () => go(6), S.busy)); c.append(row);
  } else if (S.step === 6) {
    if (S.done) { c.append(el('h2', '', S.done === 'kept' ? 'Saved' : 'Undone'), el('p', 'lead', S.done === 'kept' ? 'Your edit is saved on this Mac and on GitHub.' + (S.appNote || '') + (S.webUrl ? ' Your phone website was updated.' : S.webFail ? ' The phone website update FAILED, so it still has the old version.' : '') : S.msg)); if (S.done === 'kept' && S.webUrl) { const w = el('div', 'box'); w.append(el('h3', '', 'Your phone link'), el('pre', '', S.webUrl)); w.append(btn('Copy the link', '', () => navigator.clipboard.writeText(S.webUrl))); c.append(w); }
    if (S.done === 'kept' && S.detail) { const dd = document.createElement('details'); dd.append(el('summary', '', 'Show the technical details'), el('pre', '', S.detail)); c.append(dd); } row.append(btn('Make another edit', 'primary', () => { Object.assign(S, { step: 1, text: '', title: '', id: '', sum: null, check: null, msg: '', detail: '', done: '', appNote: '', webUrl: '', webFail: '', only: '', eta: null, pre: null, steps: 0, items: 1, doneItems: 0 }); refreshSync().then(render); })); c.append(row); return; }
    c.append(el('h2', '', 'Keep it or undo it?'), el('p', 'lead', 'If you like it, keep it. If not, undo it and the game goes back exactly as it was.'));
    const t = el('div', 'two'); const a = el('div', 'box'), b = el('div', 'box');
    a.append(el('h3', '', 'Keep this edit'), el('div', 'muted', 'Saves it and puts it on GitHub, after one more automatic check.' + (S.check && !S.check.ok ? ' The game check failed, so it will not be pushed.' : '')));
    const lab = document.createElement('label'); lab.style.cssText = 'display:flex;gap:10px;align-items:flex-start;margin:12px 0;cursor:pointer'; const cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = S.updateApp; cb.disabled = S.busy; cb.onchange = () => { S.updateApp = cb.checked; };
    lab.append(cb, el('span', '', 'Also update my College Dynasty desktop app (takes 1 to 3 minutes; if the game is open it closes and reopens by itself)')); a.append(lab);
    const lab2 = document.createElement('label'); lab2.style.cssText = lab.style.cssText; const cb2 = document.createElement('input'); cb2.type = 'checkbox'; cb2.checked = S.updateWeb; cb2.disabled = S.busy; cb2.onchange = () => { S.updateWeb = cb2.checked; };
    lab2.append(cb2, el('span', '', 'Also update my phone website (the public link for playing on your phone; only the game file is uploaded, nothing else)')); a.append(lab2);
    a.append(btn('Keep it', 'primary', async () => { S.busy = true; S.msg = 'Checking and saving...'; render(); const r = await window.api.keep(S.title, S.updateApp, S.updateWeb); S.busy = false; S.msg = r.out; S.detail = r.out + (r.app ? '\n\nDesktop app: ' + r.app.out : '') + (r.web ? '\n\nPhone website: ' + r.web.out : ''); S.webUrl = r.web && r.web.code === 0 ? r.web.url : ''; S.webFail = r.web && r.web.code !== 0 ? r.web.out : ''; S.appNote = !S.updateApp ? '' : !r.app ? '' : r.app.code === 0 ? ' Your desktop app was updated' + (r.app.reopened ? ' and reopened.' : '.') : ' The desktop app update FAILED, so it still has the old version. Use step 5 to try again.'; S.done = r.code === 0 ? 'kept' : ''; await refreshSync(); render(); }, S.busy));
    b.append(el('h3', '', 'Undo this edit'), el('div', 'muted', 'Throws away everything this edit changed and returns to the version from before it.'), btn('Undo it', 'danger', async () => { if (!confirm('Undo this edit? The changes will be thrown away.')) return; S.busy = true; render(); const r = await window.api.undo(S.id); S.busy = false; S.msg = r.out; S.done = r.code === 0 ? 'undone' : ''; await refreshSync(); render(); }, S.busy));
    t.append(a, b); c.append(t, el('pre', S.msg && /NOT PUSHED|Cannot/.test(S.msg) ? 'bad' : 'muted', S.msg));
    row.append(btn('Back', '', () => go(5)), el('div', 'sp'), el('span', 'muted', 'Not sure? Close the app. Nothing is pushed until you click Keep.')); c.append(row);
  }
}
let timer = null;
function tick() { clearInterval(timer); timer = setInterval(() => { const e = $('elapsed'); if (!e) { clearInterval(timer); return; } const m = Math.floor((Date.now() - S.startedAt) / 60000), s = Math.floor((Date.now() - S.startedAt) / 1000) % 60; e.textContent = `  ${m}:${String(s).padStart(2, '0')} elapsed`; }, 1000); }
window.api.onKeepStep(t => { S.msg = t; const pre = document.querySelector('#card pre'); if (pre && S.step === 6) pre.textContent = t; });
function showEta() {
  const b = $('eta'); if (!b) return; b.textContent = '';
  if (S.eta) { b.append(el('h3', '', `${S.eta.text} left (${S.eta.range})`), el('div', 'muted', S.eta.reason + '.'));
    const bits = []; if (S.steps) bits.push(`${S.steps} steps so far`); if (S.items > 1) bits.push(`${S.doneItems || 0} of ${S.items} items finished`);
    if (bits.length) b.append(el('div', 'muted', bits.join(' \u00B7 '))); b.append(el('div', 'muted', 'This estimate changes as the work goes on.')); }
  else if (S.pre) { b.append(el('h3', '', `${S.pre.text} in total (${S.pre.range})`), el('div', 'muted', `First guess, based on ${S.pre.basis}. A live estimate appears in a few seconds.`)); }
  else b.append(el('h3', '', 'Working out an estimate...'));
}
window.api.onProgress(p => { S.phase = p.phase; S.lines = p.lines; S.eta = p.eta; S.steps = p.steps; S.doneItems = p.done; S.items = p.items; showEta(); const f = $('feed'); if (!f) return; f.textContent = ''; (p.lines.length ? p.lines : ['Working...']).forEach(l => f.append(el('div', '', l))); });
window.api.onFinished(async d => { S.check = { ok: d.checkOk, out: d.checkOut }; S.sum = await window.api.summary(d.id); S.id = d.id; S.msg = ''; await refreshSync(); go(4); });
(async () => { await refreshSync(); const cur = await window.api.current(); if (cur.running) { S.id = cur.id; S.title = cur.title; S.startedAt = Date.parse(cur.startedAt); S.phase = cur.phase; S.step = 3; } render(); })();
setInterval(() => { if (S.step === 1) refreshSync(); }, 5000);
