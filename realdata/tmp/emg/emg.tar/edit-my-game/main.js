// Edit My Game: a step-by-step desktop guide for changing the College Dynasty game with Claude Code.
// Steps: describe the change -> review -> Claude Code works -> look at what changed -> try it -> keep it or undo it.
const { app, BrowserWindow, ipcMain, shell, dialog, powerSaveBlocker, Notification } = require('electron');
const { spawn, execFile } = require('child_process');
const path = require('path'), fs = require('fs');
const L = require('./lib.js');
const E = require('./estimate.js');
const P = require('./plan.js');
const crypto = require('crypto');
const os = require('os');

let win = null, job = null;
// Mac notifications: when an edit finishes, stops or needs you, and when macOS may be waiting for a permission. Switch on the Edit My Game screen (step 1).
let notifyOn = true, permWarned = false; const notified = [];
function notify(title, body, level = 'info') {
  notified.push({ title, body, wouldShow: notifyOn, level });
  if (!notifyOn || process.env.CLAUDE_CONSOLE_DRYRUN) return;
  // A banner (osascript, which is the way that is known to show on this Mac), a sound, a Dock bounce, and for "needs you" the title is spoken too.
  try { execFile('osascript', ['-e', 'on run argv', '-e', 'display notification (item 2 of argv) with title (item 1 of argv)', '-e', 'end run', '--', String(title), String(body)], () => {}); } catch (e) { /* optional */ }
  try { execFile('afplay', [`/System/Library/Sounds/${level === 'needs' ? 'Sosumi' : 'Glass'}.aiff`], () => {}); } catch (e) { /* optional */ }
  if (level === 'needs') {
    try { execFile('say', [String(title)], () => {}); } catch (e) { /* optional */ }
    // a window that stays until you click OK (up to an hour), so a needs-you message cannot be missed
    try { execFile('osascript', ['-e', 'on run argv', '-e', 'display dialog (item 2 of argv) with title (item 1 of argv) buttons {"OK"} default button "OK" with icon caution giving up after 3600', '-e', 'end run', '--', String(title), String(body)], () => {}); } catch (e) { /* optional */ }
  }
  try { app.dock && app.dock.bounce(level === 'needs' ? 'critical' : 'informational'); } catch (e) { /* optional */ }
}
ipcMain.handle('testNotify', () => { notify('Edit My Game test', 'If you can see and hear this, notifications from Edit My Game work.'); return true; });
ipcMain.handle('setNotify', (_e, on) => { notifyOn = !!on; return notifyOn; });
ipcMain.handle('notified', () => notified);
const DRY = !!process.env.CLAUDE_CONSOLE_DRYRUN;
const env = () => ({ ...process.env, PATH: `${process.env.HOME}/.local/bin:/usr/local/bin:/opt/homebrew/bin:${process.env.PATH || ''}` });
const run = (cmd, args, opts = {}) => new Promise(r => execFile(cmd, args, { cwd: L.PROJECT, env: env(), maxBuffer: 1 << 25, ...opts },
  (e, out, err) => r({ code: e ? (e.code || 1) : 0, out: ((out || '') + (err || '')).trim() })));
const git = (...a) => run('git', a);
const send = (ch, v) => { if (win && !win.isDestroyed()) win.webContents.send(ch, v); };
const tool = f => path.join(L.PROJECT, 'tools', f);
const history = () => L.readEntries().filter(e => e.exitCode === 0 && e.startedAt && e.finishedAt && (e.source === 'edit-my-game' || e.source === 'console')).map(e => ({ minutes: (Date.parse(e.finishedAt) - Date.parse(e.startedAt)) / 60000 }));
ipcMain.handle('estimate', (_e, items) => { const p = E.pre(history(), Math.max(1, items | 0)); return { text: 'About ' + E.fmt(p.mid), range: `${E.fmt(p.low)} to ${E.fmt(p.high)}`, basis: p.basis }; });

async function sync() {
  if ((await git('remote', 'get-url', 'origin')).code) return { remote: false };
  const dirty = (await git('status', '--porcelain')).out.split('\n').filter(l => l && !/claude-log\/|tools\/prompts\//.test(l)).length;
  const br = (await git('rev-parse', '--abbrev-ref', 'HEAD')).out;
  const ahead = +((await git('rev-list', '--count', `origin/${br}..HEAD`)).out || 0);
  return { remote: true, dirty, ahead, head: (await git('rev-parse', '--short', 'HEAD')).out };
}
function friendly(ev) {
  const rel = p => p.replace(L.PROJECT + '/', '');
  const g = (re) => { const m = re.exec(ev.text || ''); return m ? m[1].replace(/\\n/g, ' ').replace(/\\"/g, '"') : ''; };
  if (ev.name === 'Read') return 'Reading ' + rel(g(/"file_path":"([^"]+)"/));
  if (ev.name === 'Edit' || ev.name === 'Write') return 'Editing ' + rel(g(/"file_path":"([^"]+)"/));
  if (ev.name === 'Bash') return 'Running: ' + g(/"command":"([^"]{0,90})/);
  if (ev.name === 'Grep' || ev.name === 'Glob') return 'Searching the code for ' + (g(/"pattern":"([^"]{0,60})/) || 'something');
  return ev.name ? 'Using ' + ev.name : '';
}
function createWindow() {
  win = new BrowserWindow({ width: 1180, height: 820, minWidth: 900, minHeight: 640, backgroundColor: '#0b0f16', title: 'Edit My Game',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, sandbox: true } });
  win.loadFile(path.join(__dirname, 'index.html'));
  win.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
}

ipcMain.handle('sync', async () => {
  const t = setTimeout(() => { if (!permWarned) { permWarned = true; notify('Edit My Game is waiting for a permission', 'macOS may be asking to let Edit My Game open your Documents folder. Look for a pop-up and click Allow.', 'needs'); } }, 8000);
  try { if (process.env.EMG_TEST_SLOW_SYNC) await new Promise((r) => setTimeout(r, Number(process.env.EMG_TEST_SLOW_SYNC))); return await sync(); } finally { clearTimeout(t); }
});
ipcMain.handle('info', () => ({ project: L.PROJECT, dry: DRY }));
ipcMain.handle('saveWork', async () => { await git('add', '-A'); const r = await git('commit', '-q', '-m', 'Save work before a new edit'); return { out: r.out || 'Saved.' }; });
ipcMain.handle('current', () => job ? { running: true, id: job.id, title: job.title, startedAt: job.startedAt, phase: job.phase, lines: job.lines } : { running: false });

ipcMain.handle('stop', () => {
  if (!job) return false; job.stop = true; const c = job.child;
  if (c && c.pid) { const grp = sig => { try { process.kill(-c.pid, sig); } catch (e) { try { c.kill(sig); } catch (e2) { /* already ended */ } } };
    grp('SIGTERM'); setTimeout(() => grp('SIGKILL'), 4000); }
  return true;
});
ipcMain.handle('awake', () => !!(job && job.blocker != null && powerSaveBlocker.isStarted(job.blocker)));
ipcMain.handle('machine', async () => {
  const load = os.loadavg()[0], cores = os.cpus().length, batt = (await run('/bin/sh', ['-c', 'pmset -g batt 2>/dev/null | head -2'])).out;
  const ps = (await run('/bin/sh', ['-c', 'ps -Aro %cpu,command | head -12'])).out.split('\n').slice(1).map(l => { const m = /^\s*([\d.]+)\s+(.*)$/.exec(l); if (!m) return null; const app = (m[2].match(/\/([^\/]+)\.app/) || [])[1] || path.basename(m[2].split(' ')[0]); return { cpu: +m[1], name: app }; })
    .filter(x => x && x.cpu >= 30 && !/claude|Edit My Game|^node$|WindowServer|kernel_task|^ps$/i.test(x.name));
  return { load: +load.toFixed(1), cores, onBattery: /Battery Power/.test(batt), pct: ((batt.match(/(\d+)%/) || [])[1] | 0) || null, busy: ps.slice(0, 3) };
});
ipcMain.handle('plan', (_e, inputs) => { const p = P.plan(inputs || {}); return { single: p.single, items: p.items, why: p.why, switches: p.switches, stages: p.stages.map(s => ({ label: s.label, kind: s.kind, modelName: s.modelName, model: s.model, effort: s.effort || null, prompt: s.prompt })), fast: !!p.fast }; });

ipcMain.handle('start', async (_e, title, inputs) => {
  title = String(title || '').trim() || 'My edit'; inputs = inputs || {};
  if (!String(inputs.text || '').trim()) return { error: 'Write what you want changed first.' };
  if (job) return { error: 'An edit is already running.' };
  const pl = P.plan(inputs), n = pl.stages.length, sid = crypto.randomUUID();
  const id = L.nextId(), startedAt = new Date().toISOString(), before = (await git('rev-parse', '--short', 'HEAD')).out;
  const pdir = path.join(L.PROJECT, 'tools', 'prompts'); L.ensure(pdir);
  job = { id, title, prompt: pl.stages[0].prompt, startedAt, before, phase: 'Claude Code is working', lines: [], items: pl.items, steps: 0, pre: E.pre(history(), pl.items), eta: null, sid, blocker: powerSaveBlocker.start('prevent-app-suspension'), child: null, stop: false };
  let started = false;
  const RESUME_PROMPT = 'You ended your turn while work was still unsaved, or while checks may still have been running. Wait for anything still running, read the results, fix any problem, and commit your finished work (git add -A, git commit, no push). If the work is unfinished, finish it first. Then reply with one line saying what state it is in.';
  const runStage = (i, st, opts = {}) => new Promise(resolve => {
    const resume = !!opts.resume, prompt = opts.prompt || st.prompt;
    const pfile = path.join(pdir, `edit-${id}-${L.slug(title)}${n > 1 ? '-s' + (i + 1) : ''}${resume ? '-finish' : ''}.txt`); if (st.kind !== 'scripted') fs.writeFileSync(pfile, prompt + '\n');
    let child;
    if (st.kind === 'scripted') {
      const cmd = DRY ? `echo "DRY RUN: final check script"; git log --format='- %s' ${before}..HEAD | head -8` : `echo "Saved in this run:"; git log --format='- %s' ${before}..HEAD; echo; echo "Smart check of everything, run once at the end:"; node tools/check.js --all --since ${before}`;
      child = spawn('/bin/sh', ['-c', cmd], { cwd: L.PROJECT, env: env(), detached: true });
    } else if (DRY) {
      const nums = st.items && st.items.length ? st.items : [null];
      const leave = process.env.EMG_DRY_DIRTY && !resume && !started;
      const cmds = leave ? 'echo "left unsaved" >> dry-unsaved.txt' : nums.map(k => `echo "dry run $(date)" >> dry-run-notes.txt; git add -A; git commit -q -m "${resume ? 'Finished by the automatic finish step' : k ? k + '. dry run item' : 'Dry run change'}"`).join('; ');
      const long = process.env.EMG_DRY_GRANDCHILD ? "sh -c 'exec sleep 47'; " : '';
      child = spawn('/bin/sh', ['-c', `sleep 1; ${long}${cmds}; echo "DRY RUN REPORT: ${st.label} with ${st.modelName}${st.effort ? ', effort ' + st.effort : ''}."`], { cwd: L.PROJECT, detached: true });
    } else {
      const args = [tool('run-claude-task.sh'), pfile]; if (st.model) args.push('--model', st.model); if (st.effort) args.push('--effort', st.effort); args.push(started ? '--resume' : '--session-id', sid);
      child = spawn('/bin/zsh', args, { cwd: L.PROJECT, env: env(), detached: true });
    }
    if (st.kind !== 'scripted') started = true;
    job.child = child;
    let out = ''; child.stdout.on('data', d => out += d); child.stderr.on('data', d => out += d); child.on('close', code => resolve({ code, out }));
  });
  const unsaved = async () => (await git('status', '--porcelain', '--untracked-files=all')).out.split('\n').filter(l => l.trim() && !/^.. "?(claude-log|tools\/prompts)\//.test(l));
  let busy = false;
  const poll = setInterval(async () => {
    if (!job || busy) return; busy = true;
    try {
      const el = (Date.now() - Date.parse(startedAt)) / 60000; let lines = job.lines;
      if (!DRY) { const t = L.transcript(job.sid, 0, 100000); if (!t.missing) { job.steps = t.total; lines = t.events.filter(x => x.kind === 'tool').slice(-6).map(friendly).filter(Boolean); job.lines = lines; } }
      const log = (await git('log', '--format=%ct\t%s', `${before}..HEAD`)).out.split('\n').filter(Boolean).map(l => { const i = l.indexOf('\t'); return { t: +l.slice(0, i) * 1000, m: l.slice(i + 1) }; }).reverse();
      const itemC = log.filter(x => /^\s*(items?\s*)?#?\d{1,3}\b/i.test(x.m)), done = itemC.length, base = log.find(x => /^baseline/i.test(x.m));
      let pace = null;
      if (done >= 1) { const t0 = base ? base.t : Date.parse(startedAt), gaps = itemC.map((x, i) => (x.t - (i ? itemC[i - 1].t : t0)) / 60000), recent = gaps.slice(-4); pace = { overall: (itemC[done - 1].t - t0) / 60000 / done, recent: recent.reduce((a, b) => a + b, 0) / recent.length }; }
      const raw = E.live({ elapsed: el, items: job.items, done, hist: history(), pre: job.pre, pace });
      job.eta = job.eta ? { mid: 0.6 * job.eta.mid + 0.4 * raw.mid, low: 0.6 * job.eta.low + 0.4 * raw.low, high: 0.6 * job.eta.high + 0.4 * raw.high } : raw;
      job.done = done; send('progress', { phase: job.phase, lines, steps: job.steps, done, items: job.items, eta: E.describe(job.eta, raw.reason) });
    } catch (e) { /* keep going */ } finally { busy = false; }
  }, 3000);
  (async () => {
    let out = '', code = 0, scriptFailed = false, finishes = 0;
    for (let i = 0; i < n; i++) {
      const st = pl.stages[i], nm = st.modelName;
      job.phase = n > 1 ? `Stage ${i + 1} of ${n}: ${st.label} (${nm})` : `Claude Code is working (${nm})`; send('progress', { phase: job.phase, lines: job.lines });
      const r = await runStage(i, st);
      out += (n > 1 ? `\n\n## Stage ${i + 1} of ${n}: ${st.label} (${nm})\n` : '') + r.out.trim();
      if (st.kind === 'scripted') { if (r.code !== 0) { scriptFailed = true; out += '\n\n(The final check script found problems. See the lines above.)'; } continue; }
      if (r.code !== 0) { code = r.code || 1; out += job.stop ? '\n\n(You stopped the run. Items already finished stay saved.)' : '\n\n(Stopped: this stage ended with an error, so the later stages did not run.)'; break; }
      // Claude Code sometimes ends its turn with work unsaved or tests still running. Ask it, up to twice, to wait, fix and commit.
      for (let k = 1; k <= 2 && !job.stop; k++) {
        const left = await unsaved(); if (!left.length) break;
        finishes++; job.phase = `Finishing step ${k}: stage ${i + 1} left ${left.length} unsaved file${left.length === 1 ? '' : 's'}, asking Claude Code to finish and commit`; send('progress', { phase: job.phase, lines: job.lines });
        const f = await runStage(i, st, { resume: true, prompt: RESUME_PROMPT }); out += `\n\n### Automatic finishing step ${k} (stage ${i + 1} ended with ${left.length} unsaved file${left.length === 1 ? '' : 's'})\n` + f.out.trim();
        if (f.code !== 0) break;
      }
      if (!job.stop && (await unsaved()).length) notify('Edit needs you', `${title}: Claude Code left changes unsaved and could not finish them. Look at the results.`, 'needs');
    }
    clearInterval(poll); try { powerSaveBlocker.stop(job.blocker); } catch (e) { /* ignore */ } job.phase = 'Checking the game'; send('progress', { phase: job.phase, lines: job.lines });
    const check = await run('/bin/zsh', ['-c', process.env.PUBLISH_TEST_CMD || 'npm test']);
    const after = (await git('rev-parse', '--short', 'HEAD')).out, models = [...new Set(pl.stages.map(s => s.modelName))];
    L.saveEntry({ id, title, prompt: pl.stages.map((s, i) => (n > 1 ? `### Stage ${i + 1} of ${n}: ${s.label} (${s.modelName})\n` : '') + s.prompt).join('\n\n'), output: out.trim(), startedAt, finishedAt: new Date().toISOString(), exitCode: code,
      commitBefore: before, commitAfter: after, sessionId: DRY ? '' : sid, source: 'edit-my-game', items: job.items, steps: job.steps, models, stages: n, fast: !!inputs.fast, note: (check.code === 0 ? 'Game check passed.' : 'Game check FAILED.') + (inputs.fast ? ' Fast mode.' : '') + (scriptFailed ? ' The final check script found problems.' : '') + (finishes ? ` The automatic finishing step ran ${finishes} time${finishes === 1 ? '' : 's'}.` : '') + ` Model${models.length > 1 ? 's' : ''}: ${models.join(' and ')}.` });
    {
      const bad = code !== 0 || check.code !== 0 || scriptFailed, what = job.stop ? 'you stopped it. Finished items stay saved.' : code !== 0 ? 'a stage ended with an error. Finished items stay saved.' : check.code !== 0 ? 'the game check failed.' : scriptFailed ? 'the final check found problems.' : 'it is ready for you to look at.';
      notify(job.stop ? 'Edit stopped' : bad ? 'Edit finished with problems' : 'Edit finished', `${title}: ${what}${finishes ? ` (finished and saved automatically ${finishes} time${finishes === 1 ? '' : 's'})` : ''}`);
    }
    const done = { id, ok: code === 0, checkOk: check.code === 0, checkOut: check.out.split('\n').slice(-6).join('\n') };
    job = null; send('finished', done);
  })();
  return { id };
});

ipcMain.handle('summary', async (_e, id) => {
  const e = L.readEntries().find(x => x.id === id); if (!e) return null;
  await git('add', '-A', '--', '.', ':(exclude)claude-log', ':(exclude)tools/prompts');
  const stat = await git('diff', '--cached', '--numstat', e.commitBefore, '--', '.', ':(exclude)claude-log', ':(exclude)tools/prompts');
  const files = stat.out.split('\n').filter(Boolean).map(l => { const [a, d, f] = l.split('\t'); return { add: a, del: d, file: f }; });
  const unsaved = (await git('diff', '--cached', '--name-only')).out.split('\n').filter(Boolean).length;
  return { title: e.title, report: e.output, before: e.commitBefore, after: e.commitAfter, files, uncommitted: unsaved, note: e.note };
});
ipcMain.handle('tryBrowser', async () => { await run('node', [tool('build.js')]); const f = fs.readdirSync(path.join(L.PROJECT, 'dist')).filter(x => /\.html$/.test(x)).sort().pop(); if (f) shell.openPath(path.join(L.PROJECT, 'dist', f)); return { out: f ? 'Opened ' + f : 'No built game found.' }; });
// Rebuilds and installs the College Dynasty desktop app. If the game is open it is closed first (the game saves after every action) and reopened after.
async function updateGameApp(openAfter) {
  if (DRY) return { code: 0, out: 'DRY RUN: the desktop app would be updated here.', reopened: false };
  const wasOpen = (await run('pgrep', ['-f', 'College Dynasty.app/Contents/MacOS'])).code === 0;
  if (wasOpen) { await run('osascript', ['-e', 'tell application "College Dynasty" to quit']); await new Promise(r => setTimeout(r, 3000)); }
  const r = await run('/bin/zsh', [tool('make-desktop-app.sh'), '--install'], { timeout: 900000 });
  const reopen = r.code === 0 && (wasOpen || openAfter); if (reopen) shell.openPath('/Applications/College Dynasty.app');
  return { code: r.code, out: r.out.split('\n').slice(-3).join('\n'), reopened: reopen && wasOpen };
}
ipcMain.handle('tryApp', () => updateGameApp(true));
async function publishWeb() {
  if (DRY) return { code: 0, out: 'PUBLISHED: https://example.github.io/dry-run/', url: 'https://example.github.io/dry-run/' };
  const r = await run('/bin/zsh', [tool('publish-web.sh')], { timeout: 900000 }); const m = /https:\/\/\S+github\.io\/\S+/.exec(r.out);
  return { code: r.code, out: r.out.split('\n').slice(-3).join('\n'), url: m ? m[0] : '' };
}
// The saved changes that are only on this Mac (shown when you click the GitHub status box), and how many files are unsaved.
ipcMain.handle('unpushed', async () => {
  const s = await sync(); if (!s.remote) return { ...s, commits: [] };
  const br = (await git('rev-parse', '--abbrev-ref', 'HEAD')).out;
  const commits = (await git('log', '--format=%h\t%s', `origin/${br}..HEAD`)).out.split('\n').filter(Boolean).map((l) => { const i = l.indexOf('\t'); return { h: l.slice(0, i), s: l.slice(i + 1) }; });
  return { ...s, commits, running: !!job };
});
ipcMain.handle('keep', async (_e, title, alsoApp, alsoWeb) => {
  // Pushing saves everything first (git add -A), so it must never run while Claude Code is still editing.
  if (job) return { code: 9, out: 'An edit is running right now. Wait until it finishes, then push.', app: null, web: null };
  send('keepStep', 'Checking the game, then saving to GitHub...');
  const r = await run('/bin/zsh', [tool('publish.sh'), `Claude Code: ${title}`], { timeout: 900000 });
  if (r.code !== 0) { notify('Not pushed', 'The game check or the push did not go through, so nothing left your Mac. Open Edit My Game to see why.'); return { code: r.code, out: r.out, app: null, web: null }; }
  let app = null, web = null;
  if (alsoWeb) { send('keepStep', 'Saved. Publishing the game to your phone website (about a minute)...'); web = await publishWeb(); }
  if (alsoApp) { send('keepStep', 'Updating your desktop app (1 to 3 minutes). If the game is open it will close and reopen...'); app = await updateGameApp(false); }
  notify('Saved to GitHub', `${title}: pushed${web && web.url ? ', phone website updated' : ''}${app && app.code === 0 ? ', desktop app updated' : ''}.`);
  return { code: 0, out: r.out, app, web };
});
ipcMain.handle('undo', async (_e, id) => {
  const e = L.readEntries().find(x => x.id === id); if (!e) return { code: 1, out: 'That edit was not found.' };
  const br = (await git('rev-parse', '--abbrev-ref', 'HEAD')).out;
  // Safe only if everything already on GitHub is inside the version before the edit (nothing the edit added was pushed).
  if ((await git('merge-base', '--is-ancestor', `origin/${br}`, e.commitBefore)).code) return { code: 1, out: 'Cannot undo safely: part of this edit (or later work) is already on GitHub. Ask Claude Code to undo it instead.' };
  const r = await git('reset', '--hard', e.commitBefore); await run('node', [tool('build.js')]);
  return { code: r.code, out: r.code ? r.out : `Back to the version from before this edit (${e.commitBefore}).` };
});
ipcMain.handle('readList', () => { const f = path.join(L.PROJECT, 'my-list.md'); return fs.existsSync(f) ? fs.readFileSync(f, 'utf8') : ''; });
ipcMain.handle('openProject', () => shell.openPath(L.PROJECT));

app.on('before-quit', e => { if (job && !app.quitConfirmed) { const c = dialog.showMessageBoxSync(win, { type: 'warning', buttons: ['Keep working', 'Quit anyway'], defaultId: 0, message: 'Claude Code is still working on your edit.', detail: 'If you quit now, the edit may be left unfinished.' }); if (c === 0) e.preventDefault(); else app.quitConfirmed = true; } });
app.setName('Edit My Game');
app.whenReady().then(() => { createWindow(); app.on('activate', () => { if (!BrowserWindow.getAllWindows().length) createWindow(); }); });
app.on('window-all-closed', () => app.quit());
