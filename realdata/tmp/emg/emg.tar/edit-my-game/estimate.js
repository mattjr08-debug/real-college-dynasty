// Time estimates for Edit My Game. Pure functions, no Electron, so they can be tested on their own.
// pre():  the estimate before sending, from earlier edits (or a per-item guess for a list).
// live(): the estimate while Claude Code works, updated from how long it has run and how many items are finished.
const pct = (arr, p) => { const s = [...arr].sort((a, b) => a - b); if (!s.length) return null; const i = (s.length - 1) * p, l = Math.floor(i), h = Math.ceil(i); return s[l] + (s[h] - s[l]) * (i - l); };
const fmt = m => { m = Math.max(1, Math.round(m)); if (m < 90) return m + ' min'; const h = Math.floor(m / 60), r = m % 60; return r ? `${h} h ${r} min` : `${h} h`; };

function pre(hist, items) {
  const ok = hist.map(x => x.minutes).filter(m => m >= 1 && m <= 600);
  if (items >= 3) { const mid = Math.max(8, 4 * items); return { low: Math.round(mid * 0.5), mid, high: Math.round(mid * 2.5), n: 0, kind: 'list', basis: `a rough first guess of about 4 minutes per item for ${items} items. It will sharpen as soon as the first item is finished` }; }
  if (ok.length >= 4) { const low = Math.round(pct(ok, 0.25)), mid = Math.round(pct(ok, 0.5)), high = Math.round(pct(ok, 0.75)); return { low, mid, high, n: ok.length, kind: 'single', basis: `your ${ok.length} earlier edits (a typical one took ${fmt(mid)}; a quarter took longer than ${fmt(high)})` }; }
  return { low: 10, mid: 25, high: 40, n: ok.length, kind: 'default', basis: 'a general guess, because there are not enough earlier edits yet' };
}

function live({ elapsed, items, done, hist, pre: p, pace }) {
  const el = Math.max(elapsed, 0.2);
  if (items >= 3 && done >= 1) {
    const d = Math.min(done, items);
    if (pace && pace.overall > 0) { const per = pace.recent > 0 ? 0.5 * pace.overall + 0.5 * pace.recent : pace.overall, rem = (items - d) * per + 5; return { mid: rem, low: rem * 0.65, high: rem * 1.6, reason: `${d} of ${items} items finished; recent items took about ${fmt(per)} each (the baseline setup is not counted)` }; }
    const per = el / d, rem = (items - d) * per + 3; return { mid: rem, low: rem * 0.7, high: rem * 1.5, reason: `${d} of ${items} items finished, about ${fmt(per)} each so far` };
  }
  if (p.kind === 'list') { const rem = Math.max(p.mid - el, Math.max(5, el * 0.3)); return { mid: rem, low: rem * 0.6, high: rem * 2, reason: el > p.high ? 'longer than first guessed, still waiting for the first item to finish' : 'waiting for the first item to finish' }; }
  const D = hist.map(x => x.minutes).filter(m => m >= 1 && m <= 600), longer = D.filter(d => d > el).map(d => d - el);
  if (longer.length >= 2) return { mid: pct(longer, 0.5), low: pct(longer, 0.25), high: pct(longer, 0.75), reason: `${longer.length} earlier edits ran longer than ${fmt(el)}; they finished a median of ${fmt(pct(longer, 0.5))} later` };
  const rem = Math.max(5, el * 0.4); return { mid: rem, low: rem * 0.5, high: rem * 2, reason: `this edit has already run longer than almost every earlier one (${fmt(el)}), so this is only a guess` };
}

const describe = (e, reason) => ({ text: `About ${fmt(e.mid)}`, range: `${fmt(e.low)} to ${fmt(e.high)}`, reason: reason || '' });
module.exports = { pre, live, fmt, describe, pct };
