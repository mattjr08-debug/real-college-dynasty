// Thin launcher. The real program lives in the project folder (edit-my-game/main.js), so changing Edit My Game never changes this app,
// and macOS keeps the permissions you gave it (for example access to the Documents folder). Update = just quit and reopen the app.
const path = require('path'), os = require('os'), fs = require('fs');
const { app, dialog } = require('electron');
const dir = process.env.EDIT_MY_GAME_DIR || path.join(os.homedir(), 'Documents', 'College-Dynasty', 'edit-my-game');
const main = path.join(dir, 'main.js');
if (!fs.existsSync(main)) { app.whenReady().then(() => { dialog.showErrorBox('Edit My Game', 'Cannot find ' + main + '. Is the College-Dynasty folder still in Documents?'); app.quit(); }); }
else require(main);
